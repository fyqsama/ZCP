import torch
import torch.nn.functional as F
from torch import nn
from operations import *
from utils import drop_path
from collections import namedtuple

Genotype = namedtuple('Genotype', 'normal normal_concat reduce reduce_concat')

class Cell(nn.Module):

    def __init__(self, genotype, C_prev_prev, C_prev, C, reduction=False, reduction_prev=False):
        super(Cell, self).__init__()
        # print(C_prev_prev, C_prev, C)

        if reduction_prev:
            self.preprocess0 = FactorizedReduce(C_prev_prev, C)
        else:
            self.preprocess0 = ReLUConvBN(C_prev_prev, C, 1, 1, 0)
        self.preprocess1 = ReLUConvBN(C_prev, C, 1, 1, 0)

        if reduction:
            op_names, indices = zip(*genotype.reduce)
            concat = genotype.reduce_concat
        else:
            op_names, indices = zip(*genotype.normal)
            concat = genotype.normal_concat
        self._compile(C, op_names, indices, concat, reduction)

    def _compile(self, C, op_names, indices, concat, reduction):
        assert len(op_names) == len(indices)
        self._steps = len(op_names) // 2
        self._concat = concat
        self.multiplier = len(concat)

        self._ops = nn.ModuleList()
        for name, index in zip(op_names, indices):
            stride = 2 if reduction and index < 2 else 1
            op = OPS[name](C, stride, True)
            self._ops += [op]
        self._indices = indices

    def forward(self, s0, s1, drop_prob):
        s0 = self.preprocess0(s0)
        s1 = self.preprocess1(s1)

        states = [s0, s1]
        for i in range(self._steps):
            h1 = states[self._indices[2 * i]]
            h2 = states[self._indices[2 * i + 1]]
            op1 = self._ops[2 * i]
            op2 = self._ops[2 * i + 1]
            h1 = op1(h1)
            h2 = op2(h2)
            if self.training and drop_prob > 0.:
                if not isinstance(op1, Identity):
                    h1 = drop_path(h1, drop_prob)
                if not isinstance(op2, Identity):
                    h2 = drop_path(h2, drop_prob)
            s = h1 + h2
            states += [s]
        return torch.cat([states[i] for i in self._concat], dim=1)


class NASBlock(nn.Module):

    def __init__(self, C, genotype, layers=6):
        super(NASBlock, self).__init__()
        self._layers = layers
        self.drop_path_prob = 0.0

        self.cells = nn.ModuleList()
        C_prev_prev, C_prev, C_curr = C, C, C
        reduction_prev = False
        for i in range(layers):
            reduction = False
            cell = Cell(genotype, C_prev_prev, C_prev, C_curr, reduction, reduction_prev)
            reduction_prev = reduction
            self.cells += [cell]
            C_prev_prev, C_prev = C_prev, cell.multiplier * C_curr

        self.postprocessing = ReLUConvBN(C_prev, C, 1, 1, 0)

    def forward(self, s0, s1):
        for i, cell in enumerate(self.cells):
            s0, s1 = s1, cell(s0, s1, self.drop_path_prob)
        s1 = self.postprocessing(s1)
        return s1


def conv3x3(in_planes, out_planes, stride=1):
    """3x3 convolution with padding"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride, padding=1, bias=False)


class BasicBlockV2(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, downsample=None):
        super().__init__()
        self.bn1 = nn.BatchNorm2d(inplanes)
        self.conv1 = conv3x3(inplanes, planes, stride)
        self.bn2 = nn.BatchNorm2d(planes)
        self.conv2 = conv3x3(planes, planes)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        out = F.relu(self.bn1(x), inplace=True)
        residual = self.downsample(out) if self.downsample is not None else x
        out = self.conv1(out)
        out = F.relu(self.bn2(out), inplace=True)
        out = self.conv2(out)
        return out + residual


class WideResNet(nn.Module):
    def __init__(self, num_classes, genotype, block=BasicBlockV2, layers=[3, 4, 6, 3], width=1.0, num_inputs=3, maxpool=True):
        super().__init__()

        config = [int(v * width) for v in (64, 128, 256, 512)]
        self.inplanes = config[0]
        self.conv1 = nn.Conv2d(
            num_inputs, self.inplanes, kernel_size=5, stride=2, padding=2, bias=False
        )
        self.bn1 = nn.BatchNorm2d(self.inplanes)
        self.relu = nn.ReLU(inplace=True)
        if maxpool:
            self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        else:
            self.maxpool = nn.Identity()
        self.layer1 = self._make_layer(block, config[0], layers[0])
        self.layer2 = self._make_layer(block, config[1], layers[1], stride=2)
        self.layer3 = self._make_layer(block, config[2], layers[2], stride=2)
        self.layer4 = self._make_layer(block, config[3], layers[3], stride=2)

        self.nas_block1 = NASBlock(64, genotype)
        self.nas_block2 = NASBlock(64, genotype)
        self.nas_block3 = NASBlock(256, genotype)
        self.nas_block4 = NASBlock(512, genotype)

        self.global_pooling = nn.AdaptiveAvgPool2d(1)
        self.classifier = nn.Linear(512, num_classes)

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def _make_layer(self, block, planes, blocks, stride=1):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Conv2d(
                self.inplanes, planes * block.expansion, kernel_size=1, stride=stride, bias=False
            )

        layers = [
            block(self.inplanes, planes, stride, downsample),
        ]
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(self.inplanes, planes))

        return nn.Sequential(*layers)

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        print(self.layer1(x).shape)
        print(self.nas_block1(x, x).shape)

        x1 = self.layer1(x) + self.nas_block1(x, x)
        x2 = self.layer2(x1) + self.nas_block2(x1, x1)
        x3 = self.layer3(x2) + self.nas_block2(x2, x2)
        x4 = self.layer4(x3) + self.nas_block2(x3, x3)

        x4 = self.global_pooling(x4)
        x4 = self.classifier(x4.view(x4.size(0), -1))

        return x4