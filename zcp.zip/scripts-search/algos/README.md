# 10 NAS algorithms in NAS-Bench-201

Each script in this folder corresponds to one NAS algorithm, you can simple run it by one command.
